LOINC User's Guide and Release Notes

In order to ensure our users have the most accurate and timely information, PDF copies of LOINC Users’ Guide and LOINC Release Notes are no longer available as separate artifacts. Instead you may find these resource within the LOINC Knowledge Base, including an archive of previous Release Notes.

Please visit https://loinc.org/kb